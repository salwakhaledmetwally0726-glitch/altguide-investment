const mongoose = require('mongoose');

const investmentGoalSchema = new mongoose.Schema({
  user: mongoose.Schema.Types.ObjectId, // link to User
  title: String,                        // "Emergency fund"
  targetAmount: Number,                 // 50000
  currentAmount: Number,                // 5000
  targetDate: Date                      // "2026-12-31"
});

module.exports = mongoose.model('InvestmentGoal', investmentGoalSchema);
