const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  riskProfile: String  // "low" / "medium" / "high"
});

module.exports = mongoose.model('User', userSchema);
