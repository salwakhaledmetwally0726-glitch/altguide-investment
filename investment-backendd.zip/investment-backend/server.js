const express = require('express');
const mongoose = require('mongoose');
const app = express();
app.use(express.json());
const User = require('./models/User');
const InvestmentGoal = require('./models/InvestmentGoal');

console.log("Server file loaded, setting up routes...");

mongoose.connect
("mongodb+srv://lojainahany_db_user:Lojy1082006@cluster0.i8fbtxf.mongodb.net/Project0?retryWrites=true&w=majority")
.then(() => console.log("✅ MongoDB connected"))
.catch(err => console.log("❌ MongoDB connection error:", err));

app.post('/test', (req, res) => {
  console.log("POST /test route hit!");
  res.json({ message: "POST works!" });
});

// POST /api/users/register
app.post('/api/users/register', async (req, res) => {
  try {
    const { name, email, password, riskProfile } = req.body;
    const user = new User({ name, email, password, riskProfile });
    await user.save();
    res.status(201).json(user);
  } catch (err) {
    console.error("REGISTER ERROR:", err);;
    res.status(500).json({ message: 'Error creating user' });
  }
});

// POST /api/users/login
app.post('/api/users/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email, password });

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    res.json({ message: 'Login successful', user });
  } catch (err) {
    res.status(500).json({ message: 'Error logging in' });
  }
});

app.get('/api/users', async (req, res) => {
  const users = await User.find();
  res.json(users);
});

app.put('/api/users/:id', async (req, res) => {
  const { name, email, riskProfile } = req.body;
  const user = await User.findByIdAndUpdate(
    req.params.id,
    { name, email, riskProfile },
    { new: true }
  );
  res.json(user);
});

app.delete('/api/users/:id', async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.json({ message: 'User deleted' });
});

app.post('/api/goals', async (req, res) => {
  const { user, title, targetAmount, currentAmount, targetDate } = req.body;
  console.log("Routes loaded!");


  const goal = new InvestmentGoal({
    user,
    title,
    targetAmount,
    currentAmount,
    targetDate
  });

  await goal.save();
  res.status(201).json(goal);
});

app.get('/api/goals', async (req, res) => {
  const { userId } = req.query;
  const filter = userId ? { user: userId } : {};
  const goals = await InvestmentGoal.find(filter);
  res.json(goals);
});

app.put('/api/goals/:id', async (req, res) => {
  console.log("Updating Goal ID:", req.params.id);
  const { title, targetAmount, currentAmount, targetDate } = req.body;

  const goal = await InvestmentGoal.findByIdAndUpdate(
    req.params.id,
    { title, targetAmount, currentAmount, targetDate },
    { new: true }
  );

  res.json(goal);
});

app.delete('/api/goals/:id', async (req, res) => {
  await InvestmentGoal.findByIdAndDelete(req.params.id);
  res.json({ message: 'Goal deleted' });
});







app.listen(5000, () => {
  console.log("Server running on port 5000");
});
